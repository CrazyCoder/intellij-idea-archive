IntelliJ IDEA 1.0.4 - README

Thank you for downloading IntelliJ IDEA!

IntelliJ IDEA is a multi-platform Java IDE, which includes intelligent editor,
visual debugger, javac compiler integration, refactoring and project navigation support.

Short list of IDEA features:
==============================================================================
General:
-Java, JSP, XML, HTML support 
-Compile, Run, Debug, Compile Modified 
-Advanced code refactoring support with super-fast usage search engine 
-Target JDK switching 
-Support of different code styles 
-Multi-level undo/redo of any editing, navigation and code transformation operations 

User Interface:
-Specially designed for fast work with the keyboard. 100% of features available without using the mouse. 
-Convenient multi-pane layout with easy switching between panes 
-Commander, Project View, Structure View 
-Easy navigation to any view 
-SpeedSearch in all trees and lists 

Editing:
-Java, JSP, XML, HTML and text files editing with syntax highlighting 
-Customizable editor colors and fonts 
-Editor with virtual space 
-Advanced Code Editing
-Advanced CodeCompletion (3 different types) 
-Import Assistant - helps to automatically insert import statements while typing the code 
-Quick Override/Implement methods 
-Auto-indentation of pasted text 
-Insertion of necessary imports on copying code fragments between files 
-Quick code commenting/uncommenting (both block and line comments) 
-Customizable Code Templates 
-Auto-indentation of closing brace 
-Highlighting of unknown classes, methods, variables and packages 
-QuickInfo in editor (brief information about the element at caret) 
-ParameterInfo (brief information about the method's parameters, while the caret is inside the brackets) 
-JavaDoc, QuickInfo for items in lookup lists 
-Matching braces highlighting 

Code-generation:
-Easy creation of new classes, interfaces, packages, etc 
-Easy generation of getters, setters and class constructors 
-Generation of try/catch construct for selected block 
-Creation of a copy of existing class 

Code Refactoring:
-Renaming of packages, classes, methods, fields, method parameters and local variables with reference correction 
-Moving of classes and packages with reference correction 
-Intelligent super-fast usage search engine 
-"Introduce Variable" code refactoring 
-"Extract Method" code refactoring 
-Package/Class migration utility with reference correction 

Project Navigation:
-Navigation to a class' source code by its short name 
-Quick navigation from source to JavaDoc 
-Quick navigation to declaration, type declaration or super method from the editor 
-Navigation from the source code to a corresponding item in any view (Commander, Project View, Structure View) 
-Search & Replace
-Single-file search & replace with regular expressions 
-Project-wide search & replace with regular expressions 
-Project-wide usage search 
-Single-file usage search 
-Export of results of any search operation to a text file / clipboard 

Running/Debugging:
-Fast simple debugger with convenient user interface 
-Navigation to source from exception stack traces while running/debugging 

You are encouraged to visit our IntelliJ IDEA web site at http://www.intellij.com/idea/
or to contact us via e-mail at feedback@intellij.com if you have any comments about
this release. In particular, we are very interested in any ease-of-use, user
interface suggestions that you may have. We will be posting regular updates
of our progress to our online forums.

Contents:
==============================================================================
  INSTALL.TXT         Installation instructions
  LICENSE.TXT         Software license
  README.TXT          This file
  bin/                Startup scripts for launching IntelliJ IDEA
  lib/                Library files
  help/               Online help files
  migration/          Sample migration map files
  template/           Editor templates

Installing IntelliJ IDEA
==============================================================================
  Please read the contents of the INSTALL file.

Uninstalling IntelliJ IDEA
==============================================================================
  To unintall IntelliJ IDEA simply delete the contents of 
  the IntelliJ IDEA home installation directory.

Contacting us:
==============================================================================
  sales@intellij.com       - Sales inquires, billing, order processing questions
  support@intellij.com     - Technical support (all products)
  suggestions@intellij.com - Feature suggestions
  info@intellij.com        - Product inquiries

Bug Reporting:
==============================================================================
  Send emails to bugs@intellij.com

Home Page:
==============================================================================
  http://www.intellij.com

Early Access Program
==============================================================================
  http://www.intellij.com/eap/
